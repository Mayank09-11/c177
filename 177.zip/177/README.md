# PRO-C177-Code-Ref
Create virtual env using following commands to run this project:
#### Windows:
python3.8 -m venv venv

venv\Scripts\activate.bat

pip install flask

python app.py

#### MacOS/Linux:

python3.8 -m venv venv

venv/Scripts/activate

pip install flask

python app.py